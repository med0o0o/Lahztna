import 'package:flutter/material.dart';

void main() {
  runApp(const LahztnaApp());
}

class LahztnaApp extends StatelessWidget {
  const LahztnaApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'لحظتنا',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تطبيق لحظتنا'),
      ),
      body: const Center(
        child: Text(
          'مرحباً بك في تطبيق لحظتنا الجديد!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
